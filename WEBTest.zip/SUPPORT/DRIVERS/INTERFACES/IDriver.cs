﻿using Microsoft.Playwright;

namespace $safeprojectname$.Support.Drivers.Interfaces
{
    public interface IDriver : IDisposable
    {
        IPage Page { get; }
        Task<IPage> InitializePlaywright();
    }
}
