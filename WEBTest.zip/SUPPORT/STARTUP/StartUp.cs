﻿using $safeprojectname$.Pages.Implementations;
using $safeprojectname$.Pages.Interfaces;
using $safeprojectname$.Support.Drivers.Implementations;
using $safeprojectname$.Support.Drivers.Interfaces;
using Microsoft.Playwright;
using Reqnroll.BoDi;

namespace $safeprojectname$.Support.StartUp
{
    [Binding]
    public class StartUp(IObjectContainer objectContainer)
    {
        private readonly IObjectContainer _objectContainer = objectContainer;

        [BeforeTestRun]
        public static void GlobalSetup(IObjectContainer container)
        {
            var driver = new Driver();

            container.RegisterInstanceAs<IDriver>(driver);
            container.RegisterInstanceAs<IPage>(driver.Page);

            container.RegisterTypeAs<LoginAppPage, ILoginAppPage>();
        }

        [AfterTestRun]
        public static void GlobalTeardown()
        {
            // Se precisar liberar recursos globalmente
        }
    }
}
