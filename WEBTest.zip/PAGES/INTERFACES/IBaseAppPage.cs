﻿using Microsoft.Playwright;

namespace $safeprojectname$.Pages.Interfaces
{
    public interface IBaseAppPage
    {
        IPage Page { get; }
    }
}
