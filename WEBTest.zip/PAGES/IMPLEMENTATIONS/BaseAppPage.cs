﻿using $safeprojectname$.Pages.Interfaces;
using $safeprojectname$.Support.Drivers.Interfaces;
using Microsoft.Playwright;

namespace $safeprojectname$.Pages.Implementations
{
    public class BaseAppPage : IBaseAppPage
    {
        public IPage Page { get; }

        public BaseAppPage(IDriver driver)
        {
            Page = driver.Page;
        }
    }
}
